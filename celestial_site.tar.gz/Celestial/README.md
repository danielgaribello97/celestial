# Celestial Web

Este repositorio contiene el código fuente para el sitio web de **Celestial**, una empresa colombiana dedicada al turismo privado en el Eje Cafetero y a la personalización de camisetas mediante impresión DTF. El objetivo del proyecto es ofrecer a turistas nacionales e internacionales una plataforma rápida, accesible y bilingüe (español/inglés) donde puedan descubrir tours, cotizar reservas y contactar directamente por WhatsApp.

## Funcionalidades principales

* **Bilingüe:** Todo el contenido se gestiona mediante `i18next` y se puede cambiar entre español e inglés mediante un conmutador en la cabecera.
* **Listado de tours:** Se cargan los destinos desde `src/data/destinos.json`. Cada tarjeta muestra una foto optimizada, un resumen y el precio base calculado desde `src/data/tarifas.json` para un origen predeterminado.
* **Cotizador:** Página donde el usuario selecciona origen, destino, fecha, número de personas y extras opcionales. El precio se calcula automáticamente con la fórmula especificada (`transporte_total = CEILING(personas/4) * tarifa_base`) más el costo de entradas (según temporada) y extras. Puede enviar la cotización a través de un enlace prellenado de WhatsApp.
* **Mapa interactivo (pendiente):** El código está preparado para integrar `react-leaflet` y mostrar marcadores con información de los destinos, aunque la visualización completa requerirá instalar las dependencias correspondientes.
* **Diseño responsivo y accesible:** Se utilizan [Tailwind CSS](https://tailwindcss.com/) y buenas prácticas de accesibilidad (contraste, navegación por teclado, etiquetas `alt`, etc.).
* **Datos desacoplados:** Tarifas, entradas y temporadas se encuentran en archivos JSON (`src/data/`) para facilitar su actualización sin tocar el código. En un futuro se puede reemplazar por la lectura desde una hoja de cálculo pública de Google.
* **Despliegue listo para GitHub Pages:** Incluye un flujo de GitHub Actions que construye el proyecto y publica el contenido de `dist` en la rama `gh-pages`.

## Estructura del proyecto

```txt
Celestial/
├── public/
│   └── index.html           # HTML base con metaetiquetas, fuentes y root div
├── src/
│   ├── components/          # Componentes reutilizables (Header, Footer, LanguageSwitcher, TourCard…)
│   ├── data/                # Datos estáticos de destinos, rutas, tarifas, entradas y temporadas
│   ├── i18n/                # Archivos de traducción para ES y EN
│   ├── lib/                 # Funciones de utilidades (pricing, whatsapp, sheets)
│   ├── pages/               # Páginas de React (Home, About, Services, Tours, Booking, Contact)
│   ├── App.tsx             # Configuración del enrutador y layout principal
│   ├── i18n.ts             # Configuración de i18next
│   ├── index.css           # Importaciones de Tailwind
│   └── main.tsx            # Punto de entrada de React
├── .github/workflows/
│   └── deploy.yml          # Flujo de CI/CD para desplegar en GitHub Pages
├── package.json
├── postcss.config.cjs
├── tailwind.config.cjs
├── tsconfig.json
└── vite.config.ts
```

## Instalación y ejecución local

1. Asegúrate de tener [Node.js](https://nodejs.org/) (versión 18 o superior) y npm instalados.
2. Clona este repositorio y entra al directorio:
   ```bash
   git clone https://github.com/tu_usuario/Celestial.git
   cd Celestial
   ```
3. Instala las dependencias:
   ```bash
   npm install
   ```
4. Ejecuta el entorno de desarrollo:
   ```bash
   npm run dev
   ```
   El sitio estará disponible en <http://localhost:5173>.

## Despliegue en GitHub Pages

Este proyecto incluye un flujo de GitHub Actions (`.github/workflows/deploy.yml`) que construye el sitio y lo publica en la rama `gh-pages`. Para utilizarlo:

1. Crea un repositorio en tu cuenta de GitHub llamado `Celestial` y sube el contenido de este proyecto.
2. Activa GitHub Pages en la configuración del repositorio seleccionando la rama `gh-pages` como fuente y la carpeta raíz (`/`).
3. Cada vez que hagas un *push* a la rama `main`, GitHub Actions instalará las dependencias, generará la versión de producción (`npm run build`) y publicará automáticamente el contenido de la carpeta `dist` en `gh-pages`.
4. La URL de tu sitio será similar a `https://<tu_usuario>.github.io/Celestial/`. Para usar un dominio personalizado más adelante, crea un archivo `CNAME` en la carpeta `public` con tu dominio y configura el registro DNS CNAME apuntando a `cname.vercel-dns.com` o similar según la guía de GitHub.

## Actualizar precios y datos

Los precios de transporte, entradas y temporadas se encuentran en los archivos JSON dentro de `src/data/`. Para modificarlos:

* **Tarifas de rutas:** `src/data/tarifas.json` contiene el precio base (`tarifa_base_cop`) para cada combinación de origen y destino. La fórmula de transporte es `CEILING(personas/4) * tarifa_base`.
* **Entradas:** `src/data/entradas.json` indica el valor de la entrada para cada destino según la temporada (`baja`, `media` o `alta`).
* **Temporadas:** `src/data/temporadas.json` define los rangos de fechas (formato ISO) que corresponden a cada temporada. Si la fecha de viaje no coincide con ningún rango, se aplica la temporada baja por defecto.

Modificar estos archivos recargará automáticamente la aplicación en desarrollo. Para que los cambios se reflejen en producción, simplemente *commitea* y *pushea* los cambios a `main`.

## Limitaciones

* **Hoja de cálculo de tarifas:** El proyecto está preparado para leer una hoja de cálculo pública de Google para tarifas y entradas, pero en este entorno no fue posible acceder a dicha hoja. Por ello se incluyen valores de ejemplo en los archivos JSON. Si dispones de la hoja en modo público, puedes implementar la lógica en `src/lib/sheets.ts` para sustituir los datos.
* **Mapa interactivo:** Aunque los componentes están preparados para utilizar `react-leaflet`, puede que necesites instalar las dependencias y configurarlo en tu entorno para ver los marcadores. Este repositorio utiliza coordenadas aproximadas de cada destino.

## Licencia

Las imágenes utilizadas en este proyecto fueron generadas sintéticamente para fines ilustrativos y se encuentran en el directorio `public/images`. Este código se distribuye bajo la licencia MIT.