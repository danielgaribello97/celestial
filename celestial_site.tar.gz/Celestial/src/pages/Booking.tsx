import React, { useState } from 'react';
import destinos from '../data/destinos.json';
import rutas from '../data/rutas.json';
import tarifas from '../data/tarifas.json';
import entradas from '../data/entradas.json';
import temporadas from '../data/temporadas.json';
import { calcTransportCost, calcEntryCost, calcExtrasCost } from '../lib/pricing';
import { buildWhatsAppUrl } from '../lib/whatsapp';
import { useTranslation } from 'react-i18next';
import PriceBreakdown from '../components/PriceBreakdown';

interface ExtraOption {
  id: string;
  nombre: string;
  precio: number;
  tipo: 'persona' | 'vehiculo';
}

// Define available extras. Prices here are illustrative and can be adjusted later.
const extrasList: ExtraOption[] = [
  { id: 'guia', nombre: 'Guía turístico', precio: 50000, tipo: 'vehiculo' },
  { id: 'seguro', nombre: 'Seguro de viaje', precio: 10000, tipo: 'persona' },
  { id: 'alimentacion', nombre: 'Alimentación', precio: 30000, tipo: 'persona' }
];

/**
 * Booking page providing a quote calculator and WhatsApp booking link.
 */
export default function Booking() {
  const { t, i18n } = useTranslation();
  const [origen, setOrigen] = useState((rutas as any).origenes[0]);
  const [destino, setDestino] = useState((rutas as any).destinos[0].id);
  const [fecha, setFecha] = useState('');
  const [personas, setPersonas] = useState(1);
  const [extras, setExtras] = useState<string[]>([]);
  const [result, setResult] = useState<{
    transport: number;
    entries: number;
    extras: number;
    total: number;
  } | null>(null);

  const handleExtrasChange = (id: string) => {
    setExtras(prev =>
      prev.includes(id) ? prev.filter(e => e !== id) : [...prev, id]
    );
  };

  const calculate = () => {
    if (!fecha || !origen || !destino || personas < 1) return;
    const transport = calcTransportCost(personas, origen, destino, tarifas as any);
    const entriesCost = calcEntryCost(destino, fecha, personas, entradas as any, temporadas as any);
    const selectedExtras = extrasList.filter(e => extras.includes(e.id));
    const extrasCost = calcExtrasCost(selectedExtras as any, personas);
    const total = transport + entriesCost + extrasCost;
    setResult({ transport, entries: entriesCost, extras: extrasCost, total });
  };

  const whatsappUrl = result
    ? buildWhatsAppUrl({
        origen,
        destino,
        fecha,
        personas,
        extras,
        total: result.total,
        lang: i18n.language as 'es' | 'en'
      })
    : '';

  return (
    <div className="container mx-auto pt-20 px-4 py-12">
      <h2 className="text-3xl font-heading mb-4">{t('booking_title')}</h2>
      <form
        onSubmit={e => {
          e.preventDefault();
          calculate();
        }}
        className="space-y-4 mb-8"
      >
        <div className="grid md:grid-cols-2 gap-4">
          <label className="flex flex-col">
            <span>{t('booking_origin')}</span>
            <select
              value={origen}
              onChange={e => setOrigen(e.target.value)}
              className="border p-2 rounded"
            >
              {(rutas as any).origenes.map((o: string) => (
                <option key={o} value={o}>
                  {o}
                </option>
              ))}
            </select>
          </label>
          <label className="flex flex-col">
            <span>{t('booking_destination')}</span>
            <select
              value={destino}
              onChange={e => setDestino(e.target.value)}
              className="border p-2 rounded"
            >
              {(rutas as any).destinos.map((d: any) => (
                <option key={d.id} value={d.id}>
                  {d.nombre}
                </option>
              ))}
            </select>
          </label>
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          <label className="flex flex-col">
            <span>{t('booking_date')}</span>
            <input
              type="date"
              value={fecha}
              onChange={e => setFecha(e.target.value)}
              className="border p-2 rounded"
              min={new Date().toISOString().split('T')[0]}
            />
          </label>
          <label className="flex flex-col">
            <span>{t('booking_people')}</span>
            <input
              type="number"
              min="1"
              max="20"
              value={personas}
              onChange={e => setPersonas(parseInt(e.target.value) || 1)}
              className="border p-2 rounded"
            />
          </label>
        </div>
        <div>
          <span className="block mb-2">{t('booking_extras')}</span>
          {extrasList.map(extra => (
            <label
              key={extra.id}
              className="flex items-center space-x-2 mb-2"
            >
              <input
                type="checkbox"
                checked={extras.includes(extra.id)}
                onChange={() => handleExtrasChange(extra.id)}
              />
              <span>
                {extra.nombre} (
                {extra.tipo === 'persona'
                  ? `${extra.precio.toLocaleString('es-CO')} COP/${t('booking_per_person')}`
                  : `${extra.precio.toLocaleString('es-CO')} COP`}
                )
              </span>
            </label>
          ))}
        </div>
        <button
          type="submit"
          className="bg-primary text-white px-4 py-2 rounded"
        >
          {t('booking_calculate')}
        </button>
      </form>
      {result && (
        <div className="space-y-4">
          <PriceBreakdown
            transport={result.transport}
            entries={result.entries}
            extras={result.extras}
            total={result.total}
          />
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-green-600 text-white px-4 py-2 rounded inline-block"
          >
            {t('book_whatsapp')}
          </a>
        </div>
      )}
    </div>
  );
}