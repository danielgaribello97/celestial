import destinos from '../data/destinos.json';
import tarifas from '../data/tarifas.json';
import { useTranslation } from 'react-i18next';
import TourCard from '../components/TourCard';

/**
 * Page listing all available tours/destinations.
 */
export default function Tours() {
  const { t } = useTranslation();
  const basePrice = (destId: string) => {
    const tItem = (tarifas as any[]).find((tar: any) => tar.destino === destId && tar.origen === 'Armenia');
    return tItem ? tItem.tarifa_base_cop : null;
  };
  return (
    <div className="container mx-auto pt-20 px-4 py-12">
      <h2 className="text-3xl font-heading mb-4">{t('nav.tours')}</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {destinos.map((dest: any) => (
          <TourCard key={dest.id} dest={dest} tarifa={basePrice(dest.id)} />
        ))}
      </div>
    </div>
  );
}