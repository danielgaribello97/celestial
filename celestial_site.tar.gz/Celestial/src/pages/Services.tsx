import { useTranslation } from 'react-i18next';

/**
 * Services page providing additional detail on Celestial's offerings.
 */
export default function Services() {
  const { t } = useTranslation();
  return (
    <div className="container mx-auto pt-20 px-4 py-12 space-y-8">
      <section>
        <h2 className="text-2xl font-heading mb-2">{t('services_turismo_title')}</h2>
        <p>{t('services_turismo_desc')}</p>
      </section>
      <section>
        <h2 className="text-2xl font-heading mb-2">{t('services_dtf_title')}</h2>
        <p>{t('services_dtf_desc')}</p>
      </section>
    </div>
  );
}