import { useTranslation } from 'react-i18next';

/**
 * Contact page listing ways to get in touch with Celestial.
 */
export default function Contact() {
  const { t } = useTranslation();
  return (
    <div className="container mx-auto pt-20 px-4 py-12">
      <h2 className="text-3xl font-heading mb-4">{t('contact_title')}</h2>
      <p className="mb-4">{t('contact_desc')}</p>
      <p>
        WhatsApp:{' '}
        <a
          className="text-primary underline"
          href="https://wa.me/573148767761"
        >
          +57 314 876 7761
        </a>
      </p>
      <p>
        Instagram:{' '}
        <a
          className="text-primary underline"
          href="https://www.instagram.com/turismocelestial/"
        >
          @turismocelestial
        </a>
      </p>
    </div>
  );
}