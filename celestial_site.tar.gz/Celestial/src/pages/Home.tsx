import destinos from '../data/destinos.json';
import tarifas from '../data/tarifas.json';
import { useTranslation } from 'react-i18next';
import TourCard from '../components/TourCard';
import { Link } from 'react-router-dom';

/**
 * Landing page for the Celestial site. Displays a hero section and featured tours.
 */
export default function Home() {
  const { t } = useTranslation();

  // Compute a base price for each destination using Armenia as the default origin.
  const basePrice = (destId: string) => {
    const tItem = (tarifas as any[]).find((tar: any) => tar.destino === destId && tar.origen === 'Armenia');
    return tItem ? tItem.tarifa_base_cop : null;
  };

  return (
    <div className="pt-20">
      <section className="relative">
        <img
          src="/images/49e068c0-e85c-4936-8213-e45b4d584c6b_large.webp"
          alt="Hero"
          className="w-full h-[60vh] object-cover"
        />
        <div className="absolute inset-0 bg-black bg-opacity-40 flex flex-col items-center justify-center text-center px-4">
          <h1 className="text-white text-4xl md:text-5xl font-heading mb-4">{t('slogan')}</h1>
          <p className="text-white text-lg mb-6 max-w-3xl">{t('hero_description')}</p>
          <div className="space-x-4">
            <Link to="/tours" className="bg-white text-primary px-4 py-2 rounded">
              {t('cta_view_tours')}
            </Link>
            <Link to="/booking" className="bg-primary text-white px-4 py-2 rounded">
              {t('cta_quote_now')}
            </Link>
          </div>
        </div>
      </section>
      <section className="container mx-auto py-12 px-4">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-heading">{t('featured_tours')}</h2>
          <Link to="/tours" className="text-primary underline">
            {t('learn_more')}
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {destinos.slice(0, 4).map((dest: any) => (
            <TourCard key={dest.id} dest={dest} tarifa={basePrice(dest.id)} />
          ))}
        </div>
      </section>
      <section className="bg-gray-50 py-12 px-4">
        <div className="container mx-auto grid md:grid-cols-2 gap-8">
          <div className="flex flex-col items-start">
            <h3 className="text-xl font-heading mb-2">{t('services_turismo_title')}</h3>
            <p className="mb-4">{t('services_turismo_desc')}</p>
            <Link to="/booking" className="bg-primary text-white px-3 py-2 rounded">
              {t('cta_quote_now')}
            </Link>
          </div>
          <div className="flex flex-col items-start">
            <h3 className="text-xl font-heading mb-2">{t('services_dtf_title')}</h3>
            <p className="mb-4">{t('services_dtf_desc')}</p>
            <a href="https://wa.me/573148767761" className="bg-primary text-white px-3 py-2 rounded">
              {t('cta_quote_whatsapp')}
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}