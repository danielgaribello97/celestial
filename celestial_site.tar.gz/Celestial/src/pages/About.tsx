import { useTranslation } from 'react-i18next';

/**
 * About page describing the company mission, vision and values.
 */
export default function About() {
  const { t } = useTranslation();
  return (
    <div className="container mx-auto pt-20 px-4 py-12">
      <h2 className="text-3xl font-heading mb-4">{t('about_title')}</h2>
      <p className="mb-4 leading-relaxed">{t('about_content')}</p>
    </div>
  );
}