// Utility functions to provide data from local JSON files.
// In a future iteration these functions could fetch data from
// the official Google Sheet if it is published publicly. For now
// they simply return the fallback JSON data included in the repository.

// eslint-disable-next-line @typescript-eslint/no-var-requires
import tarifas from '../data/tarifas.json';
// eslint-disable-next-line @typescript-eslint/no-var-requires
import entradas from '../data/entradas.json';
// eslint-disable-next-line @typescript-eslint/no-var-requires
import temporadas from '../data/temporadas.json';

export function getTarifas() {
  return tarifas;
}

export function getEntradas() {
  return entradas;
}

export function getTemporadas() {
  return temporadas;
}