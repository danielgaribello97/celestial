/**
 * Utility functions for calculating pricing for Celestial bookings.
 */

export interface Tarifa {
  origen: string;
  destino: string;
  tarifa_base_cop: number;
}

export interface Entrada {
  destino_id: string;
  temporada: string;
  precio_entrada_cop: number;
}

export interface Temporada {
  temporada: string;
  rangos_fecha: string[];
}

export interface Extra {
  id: string;
  nombre: string;
  precio: number;
  tipo: 'persona' | 'vehiculo';
}

/**
 * Calculates the transportation cost based on number of people and the base tariff for a given route.
 * Each vehicle can hold up to 4 people.
 */
export function calcTransportCost(
  personas: number,
  origen: string,
  destino: string,
  tarifas: Tarifa[]
): number {
  const t = tarifas.find(item => item.origen === origen && item.destino === destino);
  const tarifaBase = t ? t.tarifa_base_cop : 0;
  const vehicles = Math.ceil(personas / 4);
  return vehicles * tarifaBase;
}

/**
 * Determines the current season based on a date string in ISO format.
 */
export function calcSeason(dateStr: string, temporadas: Temporada[]): string {
  const date = new Date(dateStr);
  for (const temp of temporadas) {
    for (const range of temp.rangos_fecha) {
      const [startStr, endStr] = range.split(':');
      const start = new Date(startStr);
      const end = new Date(endStr);
      if (date >= start && date <= end) {
        return temp.temporada;
      }
    }
  }
  // Default to low season if no match
  return 'baja';
}

/**
 * Calculates the total entry cost for a destination and number of people based on the current season.
 */
export function calcEntryCost(
  destinoId: string,
  dateStr: string,
  personas: number,
  entradas: Entrada[],
  temporadas: Temporada[]
): number {
  const season = calcSeason(dateStr, temporadas);
  const priceItem = entradas.find(item => item.destino_id === destinoId && item.temporada === season);
  if (!priceItem) return 0;
  return personas * priceItem.precio_entrada_cop;
}

/**
 * Calculates the cost of any selected extras. Extras can be priced per person or per vehicle.
 */
export function calcExtrasCost(extrasSelected: Extra[], personas: number): number {
  let total = 0;
  for (const extra of extrasSelected) {
    if (extra.tipo === 'persona') {
      total += personas * extra.precio;
    } else {
      total += extra.precio;
    }
  }
  return total;
}