/**
 * Helper for building a WhatsApp URL with a prefilled reservation message.
 */
export function buildWhatsAppUrl(params: {
  origen: string;
  destino: string;
  fecha: string;
  personas: number;
  extras: string[];
  total: number;
  lang: 'es' | 'en';
}): string {
  const templateEs = [
    'Hola Celestial, quiero reservar:',
    `- Origen: ${params.origen}`,
    `- Destino: ${params.destino}`,
    `- Fecha: ${params.fecha}`,
    `- Personas: ${params.personas}`,
    `- Extras: ${params.extras.join(', ') || 'Ninguno'}`,
    `- Cotización calculada: ${params.total.toLocaleString('es-CO')} COP`
  ].join('\n');

  const templateEn = [
    'Hello Celestial, I would like to book:',
    `- Origin: ${params.origen}`,
    `- Destination: ${params.destino}`,
    `- Date: ${params.fecha}`,
    `- People: ${params.personas}`,
    `- Extras: ${params.extras.join(', ') || 'None'}`,
    `- Quotation: ${params.total.toLocaleString('en-US')} COP`
  ].join('\n');

  const message = params.lang === 'es' ? templateEs : templateEn;
  const encoded = encodeURIComponent(message);
  return `https://wa.me/573148767761?text=${encoded}`;
}