import { useTranslation } from 'react-i18next';
import { Link, NavLink } from 'react-router-dom';
import LanguageSwitcher from './LanguageSwitcher';

/**
 * Persistent header with navigation links and language switcher.
 */
export default function Header() {
  const { t } = useTranslation();
  return (
    <header className="fixed top-0 w-full bg-white shadow z-10">
      <div className="container mx-auto flex items-center justify-between p-4">
        <Link to="/" className="text-primary font-heading text-2xl">Celestial</Link>
        <nav className="hidden md:flex space-x-4">
          <NavLink to="/" end className={({ isActive }) => isActive ? 'text-primary font-bold' : ''}>{t('nav.home')}</NavLink>
          <NavLink to="/about" className={({ isActive }) => isActive ? 'text-primary font-bold' : ''}>{t('nav.about')}</NavLink>
          <NavLink to="/services" className={({ isActive }) => isActive ? 'text-primary font-bold' : ''}>{t('nav.services')}</NavLink>
          <NavLink to="/tours" className={({ isActive }) => isActive ? 'text-primary font-bold' : ''}>{t('nav.tours')}</NavLink>
          <NavLink to="/booking" className={({ isActive }) => isActive ? 'text-primary font-bold' : ''}>{t('nav.booking')}</NavLink>
          <NavLink to="/contact" className={({ isActive }) => isActive ? 'text-primary font-bold' : ''}>{t('nav.contact')}</NavLink>
        </nav>
        <div className="flex items-center space-x-2">
          <LanguageSwitcher />
        </div>
      </div>
    </header>
  );
}