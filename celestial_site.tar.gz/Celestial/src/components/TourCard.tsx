import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';

interface TourCardProps {
  dest: any;
  tarifa: number | null;
}

/**
 * Card component used to display a single tour or destination on listing pages.
 */
export default function TourCard({ dest, tarifa }: TourCardProps) {
  const { t } = useTranslation();
  const imgPath = dest.fotos && dest.fotos.length ? `/images/${dest.fotos[0]}` : '';
  return (
    <div className="border rounded-lg overflow-hidden shadow-sm flex flex-col">
      {imgPath && (
        <img
          src={imgPath}
          alt={dest.nombre}
          className="h-48 w-full object-cover"
          loading="lazy"
        />
      )}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          <h3 className="font-heading text-xl mb-2">{dest.nombre}</h3>
          <p className="text-sm text-gray-600 mb-2">{dest.resumen_es}</p>
          {tarifa && (
            <p className="font-semibold">{t('from_price', { price: tarifa.toLocaleString('es-CO') })}</p>
          )}
        </div>
        <div className="mt-4 flex flex-col space-y-2">
          {/* Link to a dedicated tour page could be implemented in the future */}
          <Link to="/booking" className="text-primary underline">
            {t('learn_more')}
          </Link>
          <a
            href={`https://wa.me/573148767761?text=${encodeURIComponent(`Hola, quiero reservar ${dest.nombre}`)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-primary text-white px-3 py-2 rounded text-center"
          >
            {t('book_whatsapp')}
          </a>
        </div>
      </div>
    </div>
  );
}