interface BreakdownProps {
  transport: number;
  entries: number;
  extras: number;
  total: number;
}

/**
 * Component to display a detailed price breakdown for a booking.
 */
export default function PriceBreakdown({ transport, entries, extras, total }: BreakdownProps) {
  return (
    <div className="border p-4 rounded-lg bg-gray-50 space-y-2">
      <div className="flex justify-between"><span>Transporte</span><span>{transport.toLocaleString('es-CO')} COP</span></div>
      <div className="flex justify-between"><span>Entradas</span><span>{entries.toLocaleString('es-CO')} COP</span></div>
      <div className="flex justify-between"><span>Extras</span><span>{extras.toLocaleString('es-CO')} COP</span></div>
      <hr />
      <div className="flex justify-between font-bold"><span>Total</span><span>{total.toLocaleString('es-CO')} COP</span></div>
    </div>
  );
}