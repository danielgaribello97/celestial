import { useTranslation } from 'react-i18next';

/**
 * Simple language switcher component. Toggles between Spanish and English.
 */
export default function LanguageSwitcher() {
  const { i18n } = useTranslation();

  const changeLang = (lng: string) => {
    i18n.changeLanguage(lng);
  };

  return (
    <div className="flex items-center space-x-1 text-sm">
      <button
        type="button"
        onClick={() => changeLang('es')}
        className={i18n.language === 'es' ? 'font-bold underline' : ''}
      >
        ES
      </button>
      <span>|</span>
      <button
        type="button"
        onClick={() => changeLang('en')}
        className={i18n.language === 'en' ? 'font-bold underline' : ''}
      >
        EN
      </button>
    </div>
  );
}