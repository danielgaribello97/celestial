import { useTranslation } from 'react-i18next';

/**
 * Simple footer displaying contact information and copyright notice.
 */
export default function Footer() {
  const { t } = useTranslation();
  return (
    <footer className="bg-primary text-white py-6 mt-12">
      <div className="container mx-auto flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0 px-4">
        <div>
          <p>WhatsApp: <a href="https://wa.me/573148767761" className="underline">+57 314 876 7761</a></p>
          <p>Instagram: <a href="https://www.instagram.com/turismocelestial/" className="underline">@turismocelestial</a></p>
        </div>
        <div>
          <p>{t('footer_rights', { year: new Date().getFullYear() })}</p>
        </div>
      </div>
    </footer>
  );
}