/**
 * Tailwind CSS configuration for the Celestial project.
 *
 * Scans your HTML and TSX files for utility classes and extends
 * the default theme with our brand colours and fonts.
 */
module.exports = {
  content: [
    './index.html',
    './src/**/*.{js,ts,jsx,tsx}'
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#0B1F3A'
        },
        accent: {
          DEFAULT: '#FFFFFF'
        }
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        heading: ['Poppins', 'sans-serif']
      }
    }
  },
  plugins: []
};